package com.flutterflow.esalon

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
